from django.apps import AppConfig


class QuerySocialConfig(AppConfig):
    name = 'querysocial'
